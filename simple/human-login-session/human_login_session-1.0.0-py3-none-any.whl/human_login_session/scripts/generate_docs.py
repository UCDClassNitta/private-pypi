#!/usr/bin/env python3
import re
from pathlib import Path
from collections.abc import Mapping
import argparse
from typing import Any, NamedTuple, TextIO
from types import MappingProxyType
import json
import io
import os
import tokenize
import requests
from importlib.metadata import metadata
from docspec_python import load_python_modules
from docspec import Argument, Class, Function, Indirection, Module, Variable, dump_module
from enum import StrEnum
from docstring_parser import parse as parse_docstring, DocstringStyle, DocstringMeta

class IndirectionData(NamedTuple):
    member: Indirection
    object_import: bool
    as_name: str
    module_name: str
    object_name: str


class DocumentationGenerator:

    def __init__(self, src_dir: str | Path, modules: list[str], out_dir: str | Path):
        self.__src_dir = Path(src_dir)
        self.__out_dir = Path(out_dir)
        self.__module_names = tuple(modules)
        self.__src_filenames: dict[str,tuple[Path,...]] = dict()
        self.__modules: dict[str,tuple[Module,...]] = dict()
        for module_name in self.module_names:
            module_dir = self.src_dir / module_name
            if (module_dir / '__init__.py').is_file:
                self.__src_filenames[module_name] = tuple([filename for filename in module_dir.glob('*.py') if not filename.name.startswith('_')])
            self.__modules[module_name] = tuple(module for module in  load_python_modules(files=[(module_name,str(filename)) for filename in self.__src_filenames[module_name]]))
        self._find_declarations()

    @property
    def src_dir(self) -> Path:
        return self.__src_dir
    
    @property
    def out_dir(self) -> Path:
        return self.__out_dir
    
    @property
    def module_names(self) -> tuple[str,...]:
        return self.__module_names
    
    @property
    def src_filenames(self) -> Mapping[str,tuple[Path,...]]:
        return MappingProxyType(self.__src_filenames)

    @property
    def modules(self) -> Mapping[str,tuple[Module,...]]:
        return MappingProxyType(self.__modules)
    @property
    def indirections(self) -> dict[str,tuple[IndirectionData,...]]:
        return self.__indirections

    @property
    def variable_declarations(self) -> dict[str,tuple[Variable,...]]:
        return self.__variable_declarations
    
    @property
    def class_declarations(self) -> dict[str,dict[str,Class]]:
        return self.__class_declarations
    
    @property
    def function_declarations(self) -> dict[str,dict[str,Function]]:
        return self.__function_declarations
    
    @property
    def symbol_table(self) -> dict[str,dict[str,str]]:
        return self.__symbol_table

    @staticmethod
    def is_object_import(member: Indirection) -> bool:
        return 2 <= len(member.target.split('.'))

    @staticmethod
    def indirect_to_import_str(member: Indirection) -> str:
        target_split = member.target.split('.')
        as_name = f' as {member.name}' if target_split[-1] != member.name else ''
        if DocumentationGenerator.is_object_import(member=member):
            module_name = '.'.join(target_split[:-1])
            return f'from {module_name} import {target_split[-1]}{as_name}'
        return f'import {member.target}{as_name}'
    
    @staticmethod
    def process_indirection(member: Indirection) -> IndirectionData:
        target_split = member.target.split('.')
        as_name = f' as {member.name}' if target_split[-1] != member.name else ''
        object_import = DocumentationGenerator.is_object_import(member=member)
        if object_import:
            module_name = '.'.join(target_split[:-1])
            object_name = target_split[-1]
        else:
            module_name = member.target
            object_name = ''
        return IndirectionData(member=member,
                               object_import=object_import,
                               as_name=as_name,
                               module_name=module_name,
                               object_name=object_name)

    @staticmethod
    def website_is_up(url: str, timeout: float = 2.0) -> bool:
        try:
            # Try HEAD first (faster, no response body)
            response = requests.head(url, allow_redirects=True, timeout=timeout)
            if response.status_code < 400:
                return True
            # Some servers reject HEAD, try GET
            response = requests.get(url, allow_redirects=True, timeout=timeout)
            return response.status_code < 400
        except requests.RequestException:
            return False

    @staticmethod
    def create_builtin_type_symbol_table() -> dict[str,str]:
        symbol_table = {'bool':'https://docs.python.org/3/library/stdtypes.html#boolean-type-bool'}
        numeric_types = ['int','float','complex']
        numeric_link = 'https://docs.python.org/3/library/stdtypes.html#numeric-types-int-float-complex'
        sequence_types = ['list','tuple','range']
        sequence_link = 'https://docs.python.org/3/library/stdtypes.html#sequence-types-list-tuple-range'
        str_types = ['str']
        str_link = 'https://docs.python.org/3/library/stdtypes.html#text-sequence-type-str'
        binseq_types = ['bytes','bytearray','memoryview']
        binseq_link = 'https://docs.python.org/3/library/stdtypes.html#binary-sequence-types-bytes-bytearray-memoryview'
        set_types = ['set','frozenset']
        set_link = 'https://docs.python.org/3/library/stdtypes.html#set-types-set-frozenset'
        mapping_types = ['dict']
        mapping_link = 'https://docs.python.org/3/library/stdtypes.html#mapping-types-dict'
        null_types = ['None']
        null_link = 'https://docs.python.org/3/library/stdtypes.html#the-null-object'
        grouped_type_links = [(numeric_types,numeric_link),(sequence_types,sequence_link),(str_types,str_link),
                              (binseq_types,binseq_link),(set_types,set_link),(mapping_types,mapping_link),(null_types,null_link)]
        for type_link in grouped_type_links:
            type_list,link = type_link
            for type_name in type_list:
                symbol_table[type_name] = link

        std_exceptions = ['BaseException', 'BaseExceptionGroup', 'GeneratorExit', 'KeyboardInterrupt', 
                          'SystemExit', 'Exception', 'ArithmeticError', 'FloatingPointError', 'OverflowError', 
                          'ZeroDivisionError', 'AssertionError', 'AttributeError', 'BufferError', 'EOFError', 
                          'ExceptionGroup', 'ImportError', 'ModuleNotFoundError', 'LookupError', 'IndexError', 
                          'KeyError', 'MemoryError', 'NameError', 'UnboundLocalError', 'OSError', 'BlockingIOError', 
                          'ChildProcessError', 'ConnectionError', 'BrokenPipeError', 'ConnectionAbortedError', 
                          'ConnectionRefusedError', 'ConnectionResetError', 'FileExistsError', 
                          'FileNotFoundError', 'InterruptedError', 'IsADirectoryError', 'NotADirectoryError', 
                          'PermissionError', 'ProcessLookupError', 'TimeoutError', 'ReferenceError', 'RuntimeError', 
                          'NotImplementedError', 'PythonFinalizationError', 'RecursionError', 'StopAsyncIteration', 
                          'StopIteration', 'SyntaxError', 'IndentationError', 'TabError', 'SystemError', 'TypeError', 
                          'ValueError', 'UnicodeError', 'UnicodeDecodeError', 'UnicodeEncodeError', 
                          'UnicodeTranslateError', 'Warning', 'BytesWarning', 'DeprecationWarning', 
                          'EncodingWarning', 'FutureWarning', 'ImportWarning', 'PendingDeprecationWarning', 
                          'ResourceWarning', 'RuntimeWarning', 'SyntaxWarning', 'UnicodeWarning', 'UserWarning']
        for exception_name in std_exceptions:
            symbol_table[exception_name] = f'https://docs.python.org/3/library/exceptions.html#{exception_name}'
        return symbol_table


    @staticmethod
    def indirect_to_link_target(module_name: str, submodule_name: str, processed_indirection: IndirectionData) -> str:
        module_name_plus_dot = f'{module_name}.'
        target_split = processed_indirection.member.target.split('.')
        if processed_indirection.member.target[0] == '.' or processed_indirection.member.target.startswith(module_name_plus_dot):
            # within package
            target_split[0] = module_name
            object_extension = f'#{target_split[-1]}'.lower() if processed_indirection.object_import else ''
            if '.'.join(target_split[:2]) == submodule_name:
                return object_extension
            return f'{"_".join(target_split[:2])}.md{object_extension}'
        else:
            object_extension = f'#{"".join(target_split)}' if processed_indirection.object_import else ''
            stdlib_url = f'https://docs.python.org/3/library/{target_split[0]}.html{object_extension}'
            if DocumentationGenerator.website_is_up(stdlib_url):
                return stdlib_url
            try:
                module_metadata = metadata(target_split[0])
                project_urls = module_metadata.get_all('Project-URL')
                if project_urls:
                    for url in project_urls:
                        url_split = url.split(',')
                        if url_split[0].lower() == 'documentation':
                            return url_split[1].strip()
            except:
                pass
            readthedocs_url = f'https://{target_split[0]}.readthedocs.io/'
            if DocumentationGenerator.website_is_up(readthedocs_url):
                return readthedocs_url
        return ''


    @staticmethod
    def link_code_segment(code: str, symbol_table: dict[str,str]):
        current_string = ''
        in_code = False
        tokens = tokenize.generate_tokens(io.StringIO(code).readline)
        for tok in tokens:
            if tok.type == tokenize.NAME:
                link = symbol_table.get(tok.string)
                name_split = tok.string.split('.')
                if link is None and len(name_split) > 1:
                    link = symbol_table.get(name_split[0])
                if link is None:
                    current_string += tok.string if in_code else f'`{tok.string}' 
                    in_code = True
                else:
                    if in_code:
                        current_string += '`'
                        in_code = False
                    current_string += f'[`{tok.string}`]({link})'
            elif tok.string:
                current_string += tok.string if in_code else f'`{tok.string}' 
                in_code = True
        return f'{current_string}`' if in_code else current_string

    def _find_declarations(self):
        indirections: dict[str,tuple[IndirectionData,...]] = dict()     # module name to list of IndirectionData
        variable_declarations: dict[str,tuple[Variable,...]] = dict()   # module name to list of variables
        class_declarations: dict[str,dict[str,Class]] = dict()          # module name to dict of class by name
        function_declarations: dict[str,dict[str,Function]] = dict()    # module name to dict of function by name
        symbol_table: dict[str,dict[str,str]] = dict()                  # module name to name/link
        for module_name in self.modules:
            print(f'Processing {module_name}...')
            for module in self.modules[module_name]:
                submodule_name = module.location.filename[len(str(self.src_dir)):].replace('/','.')
                submodule_name = submodule_name[1:-3]
                print(f'  Processing {submodule_name}...')
                module_symbol_table = symbol_table.get(submodule_name,DocumentationGenerator.create_builtin_type_symbol_table())
                for member in module.members:
                    match member:
                        case Indirection():
                            processed_indirection = DocumentationGenerator.process_indirection(member=member)
                            indirect_list = list(indirections.get(submodule_name,list()))
                            indirect_list.append(processed_indirection)
                            indirections[submodule_name] = tuple(indirect_list)
                            module_symbol_table[member.name] = DocumentationGenerator.indirect_to_link_target(module_name=module_name,
                                                                                                              submodule_name=submodule_name,
                                                                                                              processed_indirection=processed_indirection)
                        case Variable():
                            variable_list = list(variable_declarations.get(submodule_name,list()))
                            variable_list.append(member)
                            variable_declarations[submodule_name] = tuple(variable_list)
                            module_symbol_table[member.name] = f'#{member.name}'.replace('.','-').lower()
                        case Class():
                            module_class_dict = class_declarations.get(submodule_name,dict())
                            module_class_dict[member.name] = member
                            class_declarations[submodule_name] = module_class_dict
                            module_symbol_table[member.name] = f'#{member.name}'.replace('.','-').lower()
                        case Function():
                            function_dict = function_declarations.get(submodule_name,dict())
                            function_dict[member.name] = member
                            function_declarations[submodule_name] = function_dict
                            module_symbol_table[member.name] = f'#{member.name}'.replace('.','-').lower()
                        case _:
                            print(f'  {member} of type????')
                symbol_table[submodule_name] = module_symbol_table
                print(f'  Done!')
            print(f'Done!')
        self.__indirections = indirections
        self.__variable_declarations = variable_declarations
        self.__class_declarations = class_declarations
        self.__function_declarations = function_declarations
        self.__symbol_table = symbol_table
    
    def output_link(self, out_file: TextIO, link_location: str):
        out_file.write(f'<a id="{link_location}"></a>\n\n')

    def output_docstring_examples(self, out_file: TextIO, meta: DocstringMeta):
        if self.__current_meta_type != meta.args[0]:
            out_file.write(f'***Example***\n')
        out_file.write(f'```python\n{meta.description}\n```\n\n')
        

    def output_docstring_raises(self, out_file: TextIO, meta: DocstringMeta, symbol_table: dict[str,str] | None):
        if self.__current_meta_type != meta.args[0]:
            out_file.write(f'***Raises***\n\n')
        raise_type = DocumentationGenerator.link_code_segment(meta.args[1],symbol_table=symbol_table if symbol_table else dict())
        out_file.write(f'{raise_type} - {meta.description}\n\n')

    def output_docstring_attribute(self, out_file: TextIO, meta: DocstringMeta):
        if self.__current_meta_type != meta.args[0]:
            out_file.write(f'***Attributes***\n')
        out_file.write(f'```python\n{meta.args[1]}\n```\n{meta.description}\n\n')

    def output_docstring_parameter(self, out_file: TextIO, meta: DocstringMeta, function: Function | None = None, symbol_table: dict[str,str] | None = None):
        if self.__current_meta_type != meta.args[0]:
            out_file.write(f'***Parameters***\n\n')
        parameter_name = meta.args[1]
        parameter_type = ''
        if function and symbol_table:
            parameter_split = parameter_name.split('(')
            if 1 == len(parameter_split):
                for arg in function.args:
                    if arg.name == parameter_name:
                        parameter_type = arg.datatype
                        break
            else:
                parameter_name = parameter_split[0].strip()
                parameter_type = parameter_split[1].split(')')[0].strip()
            if parameter_type:
                parameter_type = f' ({parameter_type})'
                parameter_type = DocumentationGenerator.link_code_segment(parameter_type,symbol_table=symbol_table)[1:]
        if not parameter_type:
            parameter_type = '`'
        parameter_name_and_type = f'`{parameter_name}{parameter_type}'
        out_file.write(f'{parameter_name_and_type} - {meta.description}\n\n')

    def output_docstring_returns(self, out_file: TextIO, meta: DocstringMeta, function: Function | None = None, symbol_table: dict[str,str] | None = None):
        if self.__current_meta_type != meta.args[0]:
            out_file.write(f'***Returns***\n\n')
        return_type = meta.args[1] if 1 < len(meta.args) else (function.return_type if function else None)
        if return_type and symbol_table:
            return_type = DocumentationGenerator.link_code_segment(code=return_type,symbol_table=symbol_table)
        out_file.write(f'{return_type} - {meta.description}\n\n')

    def output_docstring_meta(self, out_file: TextIO, meta: DocstringMeta, function: Function | None = None, symbol_table: dict[str,str] | None = None):
        match meta.args[0]:
            case 'examples':
                self.output_docstring_examples(out_file=out_file,meta=meta)
            case 'raises':
                self.output_docstring_raises(out_file=out_file,meta=meta,symbol_table=symbol_table)
            case 'attribute':
                self.output_docstring_attribute(out_file=out_file,meta=meta)
            case 'param':
                self.output_docstring_parameter(out_file=out_file,meta=meta,function=function,symbol_table=symbol_table)
            case 'returns':
                self.output_docstring_returns(out_file=out_file,meta=meta,function=function,symbol_table=symbol_table)
            case _:
                print(f'*****  UNKONWN META {meta.args}  *****')
        self.__current_meta_type = meta.args[0]

    def output_imports(self, out_file: TextIO, submodule_name: str):
        module_symbol_table = self.symbol_table[submodule_name]
        imports_by_package: dict[str,list[IndirectionData]] = dict()
        for indirection_data in self.indirections[submodule_name]:
            object_list = imports_by_package.get(indirection_data.module_name, list())
            object_list.append(indirection_data)
            imports_by_package[indirection_data.module_name] = object_list
        if imports_by_package:
            out_file.write('## Imports\n\n')
        for module_name, object_list in sorted(imports_by_package.items()):
            if len(object_list) == 1:
                indirection_data = object_list[0]
                as_name = f'`{indirection_data.as_name}`' if indirection_data.as_name else ''
                object_link = module_symbol_table[indirection_data.member.name]
                module_link = object_link.split('#')[0]
                if indirection_data.object_import:
                    out_file.write(f'`from `[`{indirection_data.module_name}`]({module_link})` import `[`{indirection_data.object_name}`]({object_link}){as_name}\n\n')
                else:
                    out_file.write(f'`import `[`{indirection_data.module_name}`]({object_link}){as_name}\n\n')
            else:
                import_object_list: list[str] = list()
                for indirection_data in object_list:
                    as_name = f'`{indirection_data.as_name}`' if indirection_data.as_name else ''
                    object_link = module_symbol_table[indirection_data.member.name]
                    module_link = object_link.split('#')[0]
                    import_object_list.append(f'[`{indirection_data.object_name}`]({object_link}){as_name}')
                object_list_str = '`, `'.join(sorted(import_object_list))
                out_file.write(f'`from `[`{indirection_data.module_name}`]({module_link})` import (`{object_list_str}`)`\n\n')

    def output_variables(self, out_file: TextIO, submodule_name: str):
        module_symbol_table = self.symbol_table[submodule_name]
        variable_declarations = self.variable_declarations.get(submodule_name,list())
        if variable_declarations:
            out_file.write('## Variables\n\n')
        for variable in variable_declarations:
            link_location = module_symbol_table[variable.name]
            if link_location[0] == '#':
                link_location = link_location[1:]
            self.output_link(out_file=out_file,link_location=link_location)
            if isinstance(variable.value,str):
                value_output = DocumentationGenerator.link_code_segment(code=variable.value,symbol_table=module_symbol_table)
                if value_output[0] == '`':
                    value_output = value_output[1:]
                else:
                    value_output = f'`{value_output}'
                if value_output[-1] != '`':
                    value_output = f'{value_output}`'
                out_file.write(f'`{variable.name} = {value_output}\n\n')
            else:
                out_file.write(f'`{variable.name}`\n\n')


    def output_classes(self, out_file: TextIO, submodule_name: str):
        module_symbol_table = self.symbol_table[submodule_name]
        class_declarations = self.class_declarations.get(submodule_name,dict())
        if class_declarations:
            out_file.write('## Classes\n\n')
        for class_name,class_info in class_declarations.items():
            link_location = module_symbol_table[class_name]
            if link_location[0] == '#':
                link_location = link_location[1:]
            self.output_link(out_file=out_file,link_location=link_location)
            base_class_list_str = ', '.join(class_info.bases if class_info.bases else list())
            out_file.write(f'### {class_name}\n\n')
            out_file.write(f'```python\nclass {class_name}({base_class_list_str})\n```\n\n')
            docstring = class_info.docstring
            if docstring and docstring.content:
                parsed_docstring = parse_docstring(docstring.content,style=DocstringStyle.GOOGLE)
                out_file.write(f'{parsed_docstring.short_description}\n\n')
                if parsed_docstring.long_description:
                    out_file.write(f'{parsed_docstring.long_description}\n\n')
                self.__current_meta_type = None
                for meta_value in parsed_docstring.meta:
                    self.output_docstring_meta(out_file=out_file,meta=meta_value)
                self.__current_meta_type = None
            class_variables = [member for member in class_info.members if isinstance(member,Variable)]
            if class_variables:
                out_file.write(f'***Class Attributes***\n\n```python\n')
                for variable in class_variables:
                    out_file.write(f'{variable.name} = {variable.value}\n')
                out_file.write(f'```\n\n')
            class_methods = [member for member in class_info.members if isinstance(member, Function)]
            if class_methods:
                out_file.write(f'***Methods***\n\n')
                for method in class_methods:
                    self.output_function(out_file=out_file,function=method,symbol_table=module_symbol_table,class_name=class_name)

    def output_function(self, out_file: TextIO, function: Function, symbol_table: dict[str,str], class_name: str = ''):
        def argument_to_str(arg: Argument) -> str:
            result = arg.name
            if arg.datatype:
                result += f': {arg.datatype}'
            if arg.default_value:
                result += f' = {arg.default_value}'
            return result

        heading = '####' if class_name else '###'
        function_name = function.name.replace("_","\\_")
        function_name = f'{class_name}.{function_name}' if class_name else function_name
        out_file.write(f'{heading} {function_name}\n\n')
        joined_arguments = ', '.join([argument_to_str(argument) for argument in function.args])
        return_type_str = f' -> {function.return_type}' if function.return_type else ''
        out_file.write(f'```python\ndef {function.name}({joined_arguments}){return_type_str}\n```\n\n')
        docstring = function.docstring
        if docstring and docstring.content:
            parsed_docstring = parse_docstring(docstring.content,style=DocstringStyle.GOOGLE)
            
            out_file.write(f'{parsed_docstring.short_description}\n\n')
            if parsed_docstring.long_description:
                out_file.write(f'{parsed_docstring.long_description}\n\n')
            self.__current_meta_type = None
            for meta_value in parsed_docstring.meta:
                self.output_docstring_meta(out_file=out_file,meta=meta_value,function=function,symbol_table=symbol_table)
            self.__current_meta_type = None


    def output_functions(self, out_file: TextIO, submodule_name: str):
        module_symbol_table = self.symbol_table[submodule_name]
        function_dict = self.function_declarations.get(submodule_name,dict())
        if function_dict:
            out_file.write('## Functions\n\n')
        for function_name,function_info in function_dict.items():
            link_location = module_symbol_table[function_name]
            if link_location[0] == '#':
                link_location = link_location[1:]
            self.output_link(out_file=out_file,link_location=link_location)
            self.output_function(out_file=out_file,function=function_info,symbol_table=module_symbol_table)

    def output_markdown_file(self, module: Module):
        submodule_name = module.location.filename[len(str(self.src_dir)):].replace('/','.')
        submodule_name = submodule_name[1:-3]
        print(f'  Outputting {submodule_name}...')
        output_path = self.out_dir / (submodule_name.replace('.','_') + '.md')
        os.makedirs(output_path.parent,exist_ok=True)
        with open(output_path,'w') as out_file:
            out_file.write(f'# {submodule_name}\n\n')
            self.output_imports(out_file=out_file,
                                submodule_name=submodule_name)
            self.output_variables(out_file=out_file,
                                submodule_name=submodule_name)
            self.output_classes(out_file=out_file,
                                submodule_name=submodule_name)
            self.output_functions(out_file=out_file,
                                submodule_name=submodule_name)
        print(f'  Done!')

    def output_module_index(self, out_file: TextIO, module: Module):
        submodule_name = module.location.filename[len(str(self.src_dir)):].replace('/','.')
        submodule_name = submodule_name[1:-3]
        submodule_link = submodule_name.replace('.','_')
        submodule_link += '.md'
        module_symbol_table = self.symbol_table[submodule_name]
        out_file.write(f'## [{submodule_name}]({submodule_link})\n\n')
        heading_output = False
        for variable in sorted(self.variable_declarations.get(submodule_name,list()),key= lambda obj: obj.name):
            if not heading_output:
                out_file.write(f'### Variables\n\n')
                heading_output = True
            link_location = module_symbol_table[variable.name]
            if link_location[0] == '#':
                link_location = f'{submodule_link}{link_location}'
                out_file.write(f'  - [`{variable.name}`]({link_location})\n\n')
        heading_output = False
        for class_name, class_info in sorted(self.class_declarations.get(submodule_name,list()).items()):
            if not heading_output:
                out_file.write(f'### Classes\n\n')
                heading_output = True
            link_location = module_symbol_table[class_info.name]
            if link_location[0] == '#':
                link_location = f'{submodule_link}{link_location}'
                out_file.write(f'  - [`{class_info.name}`]({link_location})\n\n')
                for member in class_info.members:
                    if isinstance(member,Function):
                        function_link = f'{link_location}{member.name.lower()}'
                        out_file.write(f'    - [`{member.name}`]({function_link})\n\n')
            

    def output_index(self, module_name: str):
        with open(self.out_dir / 'index.md','w') as out_file:
            out_file.write(f'# {module_name}\n\n')
            for module in sorted(self.modules[module_name],key=lambda obj: obj.location.filename):
                self.output_module_index(out_file=out_file,module=module)
    
    def output_markdown(self):
        for module_name in self.modules:
            print(f'Outputting for {module_name}...')
            for module in self.modules[module_name]:
                self.output_markdown_file(module=module)
            print(f'  Outputting index for {module_name}')
            self.output_index(module_name=module_name)
            print(f'Done!')

def main():
    parser = argparse.ArgumentParser(
        description='Generate one Markdown file per module'
    )
    parser.add_argument('-o', '--output', default='./docs',
                        help='Path to the output directory for Markdown files')
    parser.add_argument('-s', '--source', 
                        help='Path to source directory.')
    parser.add_argument('-m', '--modules', nargs='+',
                        help='Names of the modules to load.')
    args = parser.parse_args()

    doc_generator = DocumentationGenerator(src_dir=args.source,
                                           modules=args.modules,
                                           out_dir=args.output)

    doc_generator.output_markdown()

if __name__ == '__main__':
    main()
