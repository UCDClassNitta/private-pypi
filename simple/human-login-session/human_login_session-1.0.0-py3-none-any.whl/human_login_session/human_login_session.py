from __future__ import annotations

from urllib.parse import urlparse, parse_qsl, unquote_plus, urlsplit, urlencode, ParseResult
from playwright.sync_api import Browser, BrowserContext, Page, Playwright, sync_playwright
from playwright.sync_api._generated import Response as PWResponse, Request as PWRequest
from playwright._impl._api_structures import SetCookieParam
from requests import Session, Response, Request, PreparedRequest
#from requests.models import Response
from requests.structures import CaseInsensitiveDict
from requests.cookies import RequestsCookieJar
from typing import MutableMapping

# Based off of https://stackoverflow.com/questions/5371992/comparing-two-urls-in-python    
class Url(object):
    '''A url object that can be compared with other url orbjects
    without regard to the vagaries of encoding, escaping, and ordering
    of parameters in query strings.'''

    LOCAL_HOST      = 'localhost'
    SCHEME_HTTPS    = 'https'

    def __init__(self, url : str, params : dict[str,str | list[str]] | list[tuple[str,str]] | str | bytes | None = None):
        parts = urlparse(url if url[-1] != '/' else url[:-1])
        params_as_dict = Url.normalize_params_to_dict(params=params)
        parts_params_as_dict = Url.normalize_params_to_dict(params=parts.query)
        query = Url.merge_param_dict(params1=parts_params_as_dict,params2=params_as_dict)
        path = unquote_plus(parts.path)
        parts = parts._replace(query=query, path=path)
        self.__parts = parts

    def __eq__(self, other : Url):
        return self.parts == other.parts

    def __hash__(self):
        items = list()
        for key, value in self.params.items():
            if isinstance(value, list):
                for v in value:
                    items.append((key, v))
            else:
                items.append((key, value))
        params_tuple = tuple(sorted(items))
        return hash((self.scheme,
                     self.hostname,
                     self.path,
                     params_tuple
                     ))

    @property
    def parts(self) -> ParseResult:
        return self.__parts
    
    @property
    def netloc(self) -> str:
        return self.parts.netloc
    
    @property
    def hostname(self) -> str:
        return self.parts.hostname if self.parts.hostname else self.LOCAL_HOST

    @property
    def path(self) -> str:
        return self.parts.path

    @property
    def scheme(self) -> str:
        return self.parts.scheme

    @property
    def params(self) -> dict[str,str|list[str]]:
        return Url.normalize_params_to_dict(self.parts.query)

    @property
    def url(self) -> str:
        return f'{self.parts.scheme}://{self.parts.netloc}{self.parts.path}'

    @staticmethod
    def construct_url(netloc : str, endpoint : str, scheme : str | None = None) -> str:
        scheme = Url.SCHEME_HTTPS if scheme is None else scheme
        return f'{scheme}://{netloc.strip("/")}/{endpoint.lstrip("/")}'
        
    @staticmethod
    def add_netloc_to_action(netloc : str, action : str, scheme : str | None = None) -> str:
        scheme = Url.SCHEME_HTTPS if scheme is None else scheme
        return f'{scheme}://{netloc.strip("/")}/{action.lstrip("/")}' if f'{scheme}://' != action[:len(scheme)+3] else action

    @staticmethod
    def normalize_params_to_dict(params : dict[str,str | list[str]] | list[tuple[str,str]] | str | bytes | None) -> dict[str,str | list[str]]:
        if params is None:
            return dict()
        
        elif isinstance(params, dict):
            return dict(params)
        
        elif isinstance(params, list):
            result : dict[str,str | list[str]] = dict()
            for k, v in params:
                if k in result:
                    # convert to list if duplicate keys
                    existing = result[k]
                    if isinstance(existing, list):
                        existing.append(v)
                    else:
                        result[k] = [existing,v]
                else:
                    result[k] = v
            return result
        
        elif isinstance(params, (str, bytes)):
            if isinstance(params, bytes):
                params = params.decode('utf-8')
            # parse_qsl returns list of (key, value) pairs
            pairs = parse_qsl(params, keep_blank_values=True)
            return Url.normalize_params_to_dict(pairs)
        
        raise TypeError(f"Unsupported params type: {type(params)}")

    @staticmethod
    def merge_param_dict(params1 : dict[str, str | list[str]], params2 : dict[str, str | list[str]]) -> dict[str,str | list[str]]:
        param1_str = urlencode(params1,doseq=True)
        param2_str = urlencode(params2,doseq=True)
        if param1_str and param2_str:
            param1_str += '&'
        return Url.normalize_params_to_dict(params=param1_str + param2_str)

class HumanLoginSession:
    USER_AGENT_KEY                  = 'User-Agent'
    USER_AGENT_PAGE_KEY             = 'navigator.userAgent'

    ACCEPT_KEY                      = 'accept'
    ACCEPT_VALUE                    = ('text/html,application/xhtml+xml,application/xml;q=0.9,'
                                         'image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9')

    ACCEPT_ENCODING_KEY             = 'Accept-Encoding'
    ACCEPT_ENCODING_VALUE           = 'gzip, deflate'

    ACCEPT_LANGUAGE_KEY             = 'Accept-Language'
    ACCEPT_LANGUAGE_VALUE           = 'en-US,en;q=0.9'

    UPGRADE_INSECURE_REQUESTS_KEY   = 'Upgrade-Insecure-Requests'
    UPGRADE_INSECURE_REQUESTS_VALUE = '1'

    AUTHORIZATION_KEY               = 'authorization'
    ORIGIN_KEY                      = 'Origin'
    REFERER_KEY                     = 'Referer'
    COOKIE_CSRF_KEY                 = 'csrftoken'
    HEADER_CSRF_KEY                 = 'X-CSRFToken'

    LOAD_STATE_LOADED               = 'domcontentloaded'

    PW_RESPONSE_ENCODING            = 'content-type'


    def __init__(self):
        self.__playwright = sync_playwright().start()
        self.__headless_browser = self.playwright.chromium.launch(headless=True)
        context = self.headless_browser.new_context()
        self.__session = Session()
        self._initialize_session_headers(context=context)
    
    @property
    def playwright(self) -> Playwright:
        return self.__playwright

    @property
    def headless_browser(self) -> Browser:
        return self.__headless_browser
    
    
    @staticmethod
    def playwright_to_requests_response(pw_response: PWResponse) -> Response:
        r = Response()

        # Status & URL
        r.status_code = pw_response.status
        r.url = pw_response.url
        r.reason = pw_response.status_text

        # Headers
        r.headers = CaseInsensitiveDict(pw_response.headers)

        # Body
        body = pw_response.body()
        r._content = body

        # Encoding (best effort)
        r.encoding = pw_response.headers.get(HumanLoginSession.PW_RESPONSE_ENCODING)
        r.request = HumanLoginSession.playwright_to_prepared_request(pw_request=pw_response.request)
        return r

    @staticmethod
    def playwright_to_prepared_request(pw_request: PWRequest) -> PreparedRequest:
        req = Request(
            method=pw_request.method,
            url=pw_request.url,
            headers=pw_request.headers,
            data=pw_request.post_data
        )
        return req.prepare()

    def _initialize_session_headers(self, context: BrowserContext):
        page = context.new_page()
        
        user_agent = page.evaluate(HumanLoginSession.USER_AGENT_PAGE_KEY).replace('Headless','')
        header_update = {HumanLoginSession.USER_AGENT_KEY:user_agent,
                         HumanLoginSession.ACCEPT_KEY:HumanLoginSession.ACCEPT_VALUE,
                         HumanLoginSession.ACCEPT_ENCODING_KEY:HumanLoginSession.ACCEPT_ENCODING_VALUE,
                         HumanLoginSession.ACCEPT_LANGUAGE_KEY:HumanLoginSession.ACCEPT_LANGUAGE_VALUE,
                         HumanLoginSession.UPGRADE_INSECURE_REQUESTS_KEY:HumanLoginSession.UPGRADE_INSECURE_REQUESTS_VALUE}
        
        self.__session.headers.update(header_update)

    def _update_session_headers(self, response: PWResponse):
        auth = response.request.headers.get(self.AUTHORIZATION_KEY)
        if auth is not None:
            self.__session.headers[self.AUTHORIZATION_KEY] = auth
        
        referer = response.request.headers.get(self.REFERER_KEY)
        if referer is not None:
            self.__session.headers[self.REFERER_KEY] = referer
            parsed_referer = Url(referer)
            self.__session.headers[self.ORIGIN_KEY] = f'{parsed_referer.scheme}://{parsed_referer.hostname}'
        csrf_token = self.__session.cookies.get(self.COOKIE_CSRF_KEY)
        if csrf_token is not None:
            self.__session.headers[self.HEADER_CSRF_KEY] = csrf_token


    def _update_session_cookies(self, context: BrowserContext):
        browser_coookies = context.cookies()
        for c in browser_coookies:
            name = c.get('name')
            if name:
                value = c.get('value')
                domain = c.get('domain')
                path = c.get('path')
                secure = c.get('secure')
                if value is not None and domain is not None and path is not None and secure is not None:
                    self.__session.cookies.set(name=name,
                                               value=value,
                                               domain=domain,
                                               path=path,
                                               secure=secure)

    def _update_session(self, context: BrowserContext, response: PWResponse):
        self._update_session_cookies(context)
        self._update_session_headers(response)

    def request(self, method, url, params=None, data=None, headers=None, cookies=None, files=None,
            auth=None, timeout=None, allow_redirects=True, json=None) -> Response:
        target_url = Url(url=url,
                         params=params)
        response: Response = self.__session.request(method=method,
                                                    url=url,
                                                    params=params,
                                                    data=data,
                                                    headers=headers,
                                                    cookies=cookies,
                                                    files=files,
                                                    auth=auth,
                                                    timeout=timeout,
                                                    allow_redirects=allow_redirects,
                                                    json=json)

        parsed_response_url = Url(url=response.url)
        if target_url != parsed_response_url:
            print(f'headers = {self.__session.headers}')
            response = self.headed_request(response=response,target_url=target_url)
        
        return response
        
    def headed_request(self, response: Response, target_url: Url) -> Response:
        if Url(response.url) == target_url:
            return response
        browser = self.playwright.chromium.launch(headless=False)
        extra_http_headers: dict[str,str] = {key:str(value) for key,value in self.__session.headers.items() if key != self.USER_AGENT_KEY}
        default_user_agent = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.7499.4 Safari/537.36'
        user_agent = str(self.__session.headers.get(self.USER_AGENT_KEY,default_user_agent))
        context = browser.new_context(user_agent=user_agent,extra_http_headers=extra_http_headers)
        cookies = [SetCookieParam(name=cookie.name,value=str(cookie.value),domain=cookie.domain,path=cookie.path) for cookie in self.__session.cookies]
        context.add_cookies(cookies)
        page = context.new_page()
        page.goto(response.url)
        page.wait_for_load_state(self.LOAD_STATE_LOADED)
        while(Url(page.url) != target_url ):
            with page.expect_navigation() as nav:
                page.wait_for_load_state(self.LOAD_STATE_LOADED)
        self._update_session(context=context,response=nav.value)
        return_response = self.playwright_to_requests_response(nav.value)
        browser.close()
        return return_response
        

        
    def get(self, url, **kwargs) -> Response:
        return self.request('GET',
                            url,
                            **kwargs)

    def post(self, url, data = None, json = None, **kwargs) -> Response:
        return self.request('POST',
                            url,
                            data=data,
                            json=json,
                            **kwargs)

    def options(self, url, **kwargs):
        return self.request('OPTIONS',
                            url,
                            **kwargs)

    def head(self, url, **kwargs):
        return self.request('HEAD',
                            url,
                            **kwargs)

    def put(self, url, data = None, **kwargs):
        return self.request('PUT',
                            url,
                            data=data,
                            **kwargs)

    def patch(self, url, data=None, **kwargs):
        return self.request('PATCH',
                            url,
                            data=data,
                            **kwargs)

    def delete(self, url, **kwargs):
        return self.request('DELETE',
                            url,
                            **kwargs)


    @property
    def headers(self) -> MutableMapping[str,str | bytes]:
        return self.__session.headers

    @property
    def cookies(self) -> RequestsCookieJar:
        return self.__session.cookies
