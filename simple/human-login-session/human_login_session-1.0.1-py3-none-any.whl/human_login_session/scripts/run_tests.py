#!/usr/bin/env python3
from __future__ import annotations
import unittest
import coverage
from pathlib import Path

def main():
    # Start coverage collection
    path = Path('.')
    cover_files = [str(filename.name)[:-3] for filename in path.glob('src/*/*.py') if not str(filename).endswith('__init__.py')]
    cov = coverage.Coverage(source=cover_files)
    cov.start()

    # Discover and run tests
    loader = unittest.TestLoader()
    suite = loader.discover('tests')
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Stop coverage and save report
    cov.stop()
    cov.save()

    # Generate HTML report
    cov.html_report(directory='htmlcov')  # output directory

    # Optional: Print report summary to console
    cov.report()

    if not result.wasSuccessful():
        exit(1)

if __name__ == '__main__':
    main()
