#!/usr/bin/env python3
from __future__ import annotations

from human_login_session import HumanLoginSession, SessionLikeProtocol, Url
from canvasapi import Canvas
from canvasapi.requester import Requester
from enum import StrEnum
from requests import Response
from requests.cookies import RequestsCookieJar
from typing import MutableMapping, cast
from unittest.mock import patch
from urllib.parse import unquote
import os
import pickle
import sys

import sys, termios,atexit
# Setup for returning terminal back to settings
fd = sys.stdin.fileno()
old = termios.tcgetattr(fd)
def restore():
    termios.tcsetattr(fd, termios.TCSADRAIN, old)
atexit.register(restore)

import logging
logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(module)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.FileHandler("app.log"),
        logging.StreamHandler()  # optional: also log to console
    ],
)

logger = logging.getLogger(__name__)

logger.info('Started logging')

class RequestMethod(StrEnum):
    GET     = 'GET'
    POST    = 'POST'
    DELETE  = 'DELETE'
    PUT     = 'PUT'
    PATCH   = 'PATCH'
    OPTIONS = 'OPTIONS'
    HEAD    = 'HEAD'

class SessionWithCSRFDuplication(SessionLikeProtocol):
    CSRF_COOKIE_TOKEN       = '_csrf_token'
    X_CSRF_TOKEN_HEADER_KEY = 'x-csrf-token'
    
    def __init__(self, session: SessionLikeProtocol):
        self.__session = session
        self.__duplicate_csrf_token = True


    @property
    def duplicate_csrf_token(self) -> bool:
        return self.__duplicate_csrf_token

    @duplicate_csrf_token.setter
    def duplicate_csrf_token(self, val: bool):
        self.__duplicate_csrf_token = val

    def get_csrf_token(self, url: str) -> str:
        next_url = Url(url)
        path_components = next_url.path.split('/')
        for index in range(len(path_components), 0, -1):
            path = '/'.join(path_components[:index])
            path = path if path else '/'
            logger.debug(f'Looking for _csrf_token at {next_url.hostname} {path}')
            csrf_cookie = self.__session.cookies.get(name=self.CSRF_COOKIE_TOKEN,domain=next_url.hostname,path=path)
            if csrf_cookie is not None:
                return unquote(csrf_cookie)
        return unquote(self.__session.cookies[self.CSRF_COOKIE_TOKEN])

    def request(self, method, url, params=None, data=None, headers=None, cookies=None, files=None,
            auth=None, timeout=None, allow_redirects=True, json=None) -> Response:
        if self.duplicate_csrf_token and method != RequestMethod.GET:
            try:
                csrf_token = self.get_csrf_token(url)
                if headers is None:
                    headers = dict()
                headers[self.X_CSRF_TOKEN_HEADER_KEY] = csrf_token
            except:
                pass
        logger.debug(f'SessionWithCSRFDuplication.request({method}, {url}, )')
        response = self.__session.request(method, url, 
                                         params=params, 
                                         data=data, 
                                         headers=headers,
                                         cookies=cookies,
                                         files=files,
                                         auth=auth,
                                         timeout=timeout,
                                         allow_redirects=allow_redirects,
                                         json=json)
        return response
        
    def get(self, url, **kwargs) -> Response:
        return self.request(RequestMethod.GET,url,**kwargs)

    def post(self, url, data = None, json = None, **kwargs) -> Response:
        return self.request(RequestMethod.POST,url,data=data,json=json,**kwargs)

    def options(self, url, **kwargs) -> Response:
        return self.request(RequestMethod.OPTIONS,url,**kwargs)

    def head(self, url, **kwargs) -> Response:
        return self.request(RequestMethod.HEAD,url,**kwargs)

    def put(self, url, data = None, **kwargs) -> Response:
        return self.request(RequestMethod.PUT,url,data=data,**kwargs)

    def patch(self, url, data = None, **kwargs) -> Response:
        return self.request(RequestMethod.PATCH,url,data=data,**kwargs)

    def delete(self, url, **kwargs) -> Response:
        return self.request(RequestMethod.DELETE,url,**kwargs)

    @property
    def headers(self) -> MutableMapping[str,str | bytes]:
        return self.__session.headers

    @property
    def cookies(self) -> RequestsCookieJar:
        return self.__session.cookies

    def __getattr__(self, name: str):
        # Forward everything else transparently
        return getattr(self.__session, name)

class HumanAuthRequesterProxy:
    VIRTUAL_ENV = 'VIRTUAL_ENV'
    COOKIE_FILE = 'session_cookies.pkl'
    BASE_PREFIX = 'base_prefix'
    REAL_PREFIX = 'real_prefix'
    
    def __init__(self, base_url, access_token):
        self.__session = SessionWithCSRFDuplication(HumanLoginSession())
        self.load_session_cookies()
        response = self.__session.get(base_url,timeout=60000)
        if response.status_code == 200:
            self.store_session_cookies()
        with patch('requests.Session',new=lambda: self.__session):
            self.__real_requester = Requester(base_url=base_url,access_token=access_token)
            
    def __del__(self):
        self.store_session_cookies()

    @property
    def _session(self) -> SessionWithCSRFDuplication:
        return self.__session

    @staticmethod
    def get_cookie_filename() -> str:
        # Check environment variable first
        venv = os.environ.get(HumanAuthRequesterProxy.VIRTUAL_ENV)
        if venv:
            return f'{venv}/{HumanAuthRequesterProxy.COOKIE_FILE}'
        # Fallback to sys.prefix check
        if hasattr(sys, HumanAuthRequesterProxy.REAL_PREFIX) or (hasattr(sys, HumanAuthRequesterProxy.BASE_PREFIX) and sys.base_prefix != sys.prefix):
            return f'{sys.prefix}/{HumanAuthRequesterProxy.COOKIE_FILE}'
        # Finally, fallback to home
        return f'{os.path.expanduser('~')}/{HumanAuthRequesterProxy.COOKIE_FILE}'

    def load_session_cookies(self):
        try:
            cookie_filename = HumanAuthRequesterProxy.get_cookie_filename()
            with open(cookie_filename, 'rb') as in_file:
                self.__session.cookies.update(pickle.load(in_file))
        except Exception:
            pass

    def store_session_cookies(self):
        with open(HumanAuthRequesterProxy.get_cookie_filename(), 'wb') as out_file:
            pickle.dump(self.__session.cookies,out_file)

    def request(
        self,
        method,
        endpoint=None,
        headers:dict[str,str] | None =None,
        use_auth=True,
        _url=None,
        _kwargs=None,
        json=False,
        **kwargs
    ):
        logger.debug(f'HumanAuthRequesterProxy.request({method}, {endpoint},  {_url})')  
        

        use_auth = False
        return self.__real_requester.request(method=method,
                                             endpoint=endpoint,
                                             headers=headers,
                                             use_auth=use_auth,
                                             _url=_url,
                                             _kwargs=_kwargs,
                                             json=json,
                                             **kwargs)
    
    # Optional: delegate missing attributes to the real requester
    def __getattr__(self, name):
        return getattr(self.__real_requester, name)

def get_canvas(base_url: str,
               access_token: str) -> Canvas:
    canvas = Canvas(base_url=base_url,access_token=access_token)
    setattr(canvas,f'_{canvas.__class__.__name__}__requester',HumanAuthRequesterProxy(base_url=base_url,access_token=access_token))
    return canvas

